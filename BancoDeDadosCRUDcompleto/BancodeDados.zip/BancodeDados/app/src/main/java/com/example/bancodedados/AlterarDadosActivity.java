package com.example.bancodedados;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Bundle;

public class AlterarDadosActivity extends Activity {

    EditText txtnome, txttelefone, txtemail;
    TextView txtstatus_registro;
    SQLiteDatabase db;
    ImageView imgprimeiro, imganterior, imgproximo, imgultimo;
    Button btalterardados;
    int indice;
    int numreg;
    Cursor c;
    DialogInterface.OnClickListener diAlteraInformacoes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar_dados);

        txtnome = findViewById(R.id.txtnome);
        txttelefone = findViewById(R.id.txttelefone);
        txtemail = findViewById(R.id.txtemail);

        txtstatus_registro = findViewById(R.id.txtstatus_registro);

        imgprimeiro = findViewById(R.id.imgprimeiro);
        imganterior = findViewById(R.id.imganterior);
        imgproximo = findViewById(R.id.imgproximo);
        imgultimo = findViewById(R.id.imgultimo);

        btalterardados = findViewById(R.id.btalterardados);

        try{
            db = openOrCreateDatabase("banco_dados", Context.MODE_PRIVATE, null);
            c = db.query("usuarios", new String[] {"numreg", "nome", "telefone", "email"},
                    null, null, null, null, null);

            if(c.getCount() > 0){
                c.moveToFirst();
                indice = 1;
                numreg = c.getInt(0);
                txtnome.setText(c.getString(1));
                txttelefone.setText(c.getString(2));
                txtemail.setText(c.getString(3));

                txtstatus_registro.setText(indice + " / " + c.getCount());
            }else{
                txtstatus_registro.setText("Nenhum registro");
            }
        }catch(Exception e) {

        }
        imgprimeiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c.getCount() > 0) {
                    c.moveToFirst();
                    indice = 1;

                    txtnome.setText(c.getString(0));
                    txttelefone.setText(c.getString(1));
                    txtemail.setText(c.getString(2));

                    txtstatus_registro.setText(indice + " / " + c.getCount());
                }
            }
        });

        imganterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c.getCount() > 0) {
                    if (indice > 1) {
                        indice--;

                        c.moveToPrevious();

                        txtnome.setText(c.getString(0));
                        txttelefone.setText(c.getString(1));
                        txtemail.setText(c.getString(2));

                        txtstatus_registro.setText(indice + " / " + c.getCount());
                    }
                }
            }
        });

        imgproximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c.getCount() > 0) {
                    if (indice != c.getCount()) {
                        indice++;
                        c.moveToNext();

                        txtnome.setText(c.getString(0));
                        txttelefone.setText(c.getString(1));
                        txtemail.setText(c.getString(2));

                        txtstatus_registro.setText(indice + " / " + c.getCount());

                    }

                }
            }
        });

        imgultimo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (c.getCount() > 0) {
                    c.moveToLast();
                    indice = c.getCount();

                    txtnome.setText(c.getString(0));
                    txttelefone.setText(c.getString(1));
                    txtemail.setText(c.getString(2));

                    txtstatus_registro.setText(indice + " / " + c.getCount());

                }
            }
        });
        diAlteraInformacoes = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String nome = txtnome.getText().toString();
                String telefone = txttelefone.getText().toString();
                String email = txtemail.getText().toString();

                try{
                    db.execSQL("update usuarios set nome = '" + nome + "', telefone = '" + telefone + "', email = '" + email + "' where numreg = " + numreg);
                    MostraMensagem("Dados alterados com sucesso");
                }catch(Exception e){
                    MostraMensagem("Erro: " + e.toString());
                }
            }
        };
        btalterardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialogo = new AlertDialog.Builder(AlterarDadosActivity.this);
                dialogo.setTitle("Confirma");
                dialogo.setMessage("Deseja alterar as inforamções?");
                dialogo.setNegativeButton("Não", null);
                dialogo.setPositiveButton("Sim", diAlteraInformacoes);
                dialogo.show();
            }
        });
}


    public void MostraMensagem(String str){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(AlterarDadosActivity.this);

        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
    }

