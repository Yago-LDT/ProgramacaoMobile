package com.example.bancodedados;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.*;
import android.content.Intent;

public class MainActivity extends Activity {

    Button btcriarbanco;
    Button btcadastrardados;
    Button btcadastrardados2;
    Button btconsultardados;
    Button btalterardados;
    Button btalterardados2;
    Button btexcluirdados;
    Button btexcluirdados2;
    Intent gravaRegistroActivity;
    Intent gravaRegistroActivity2;
    Intent consultaDadosActivity;
    SQLiteDatabase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btcriarbanco = findViewById(R.id.btcriarbanco);
        btcadastrardados = findViewById(R.id.btcadastrardados);
        btcadastrardados2 = findViewById(R.id.btcadastrardados2);
        btconsultardados = findViewById(R.id.btconsultardados);
        btalterardados = findViewById(R.id.btalterardados);
        btalterardados2 = findViewById(R.id.btalterardados2);

        btexcluirdados = findViewById(R.id.btexcluirdados);
        btexcluirdados2 = findViewById(R.id.btexcluirdados2);

        btcriarbanco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    db = openOrCreateDatabase("banco_dados", Context.MODE_PRIVATE, null);
                    db.execSQL("create table if not exists " +
                            "usuarios(numreg integer primary key " +
                            "autoincrement, nome text not null, telefone text not null, " +
                            "email text not null)");
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                    dialogo.setTitle("Aviso");
                    dialogo.setMessage("Banco de dados criado com sucesso");
                    dialogo.setNeutralButton("OK", null);
                    dialogo.show();
                } catch (Exception e) {
                }
            }
        });

        btcadastrardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gravaRegistroActivity = new Intent(MainActivity.this, GravaRegistrosActivity.class);
                MainActivity.this.startActivity(gravaRegistroActivity);
            }
        });

        btcadastrardados2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               gravaRegistroActivity2 = new Intent(MainActivity.this, GravaRegistros2Activity.class);
            MainActivity.this.startActivity(gravaRegistroActivity2);
            }
        });

        btconsultardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                consultaDadosActivity = new Intent(MainActivity.this, ConsultaDadosActivity.class);
                MainActivity.this.startActivity(consultaDadosActivity);
            }
        });
        btalterardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent alterarDadosActivity = new Intent(MainActivity.this, AlterarDadosActivity.class);
                MainActivity.this.startActivity(alterarDadosActivity);
            }
        });
        btalterardados2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent alterarDados2Activity = new Intent(MainActivity.this, AlterarDados2Activity.class);
                MainActivity.this.startActivity(alterarDados2Activity);
            }
        });

        btexcluirdados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent excluirDadosActivity = new Intent(MainActivity.this, ExcluirDadosActivity.class);
                MainActivity.this.startActivity(excluirDadosActivity);
            }
        });
        btexcluirdados2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent excluirDados2Activity = new Intent(MainActivity.this,ExcluirDados2Activity.class);
                MainActivity.this.startActivity(excluirDados2Activity);
            }
        });


    }
}