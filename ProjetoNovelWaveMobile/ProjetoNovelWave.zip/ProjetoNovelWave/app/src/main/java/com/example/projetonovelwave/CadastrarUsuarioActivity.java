package com.example.projetonovelwave;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.widget.*;
import android.view.View;
import android.os.Bundle;


public class CadastrarUsuarioActivity extends Activity {
    Button btCadastrar;
    EditText edLogin;
    EditText edSenha;
    EditText edEmail;
    SQLiteDatabase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_usuario);
        btCadastrar = findViewById(R.id.btCadastrar);
        edLogin = findViewById(R.id.edLogin);
        edSenha = findViewById(R.id.edSenha);
        edEmail = findViewById(R.id.edEmail);
        try{
            db = openOrCreateDatabase("banconovelwave", Context.MODE_PRIVATE, null);

        }catch(Exception e){
            MostraMensagem("Erro: " + e.toString());
        }

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = edLogin.getText().toString();
                String senha = edSenha.getText().toString();
                String email = edEmail.getText().toString();
                try{
                    db.execSQL("insert into usuarios(login, senha, email) values ('" + login + "','"
                            + senha + "','" + email + "')");
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(CadastrarUsuarioActivity.this);
                    dialogo.setTitle("Aviso");
                    dialogo.setMessage("Dados cadastrados com sucesso!");
                    dialogo.setNeutralButton("OK", null);
                    dialogo.show();

                }catch(Exception e){
                    MostraMensagem("Erro: " + e.toString());
                }

            }
        });



    }

    private void MostraMensagem(String str) {
        AlertDialog.Builder dialogo = new AlertDialog.Builder(CadastrarUsuarioActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("Ok", null);
        dialogo.show();
    }
}