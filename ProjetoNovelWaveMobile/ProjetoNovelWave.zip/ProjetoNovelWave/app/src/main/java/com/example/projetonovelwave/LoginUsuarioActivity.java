package com.example.projetonovelwave;

import android.app.Activity;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.View;
import android.widget.*;
import android.content.Intent;

public class LoginUsuarioActivity extends Activity {
Button btLogar;
EditText edLoginEntrar;
EditText edSenhaEntrar;
SQLiteDatabase db;
Intent catalogoActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_usuario);

        btLogar = findViewById(R.id.btLogar);
        edLoginEntrar = findViewById(R.id.edLoginEntrar);
        edSenhaEntrar = findViewById(R.id.edSenhaEntrar);

        db = openOrCreateDatabase("banconovelwave", Context.MODE_PRIVATE, null);

        btLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String login = edLoginEntrar.getText().toString();
            String senha = edSenhaEntrar.getText().toString();
                try{
                    Cursor c = db.rawQuery(
                            "SELECT * FROM usuarios WHERE login = ? AND senha = ?",
                            new String[]{login, senha}
                    );

                    if (c.moveToFirst()) {
                        AlertDialog.Builder dialogo = new AlertDialog.Builder(LoginUsuarioActivity.this);
                        dialogo.setTitle("Aviso");
                        dialogo.setMessage("Login realizado com sucesso!");
                        dialogo.setNeutralButton("OK", null);
                        dialogo.show();

                        catalogoActivity = new Intent(LoginUsuarioActivity.this, CatalogoActivity.class);
                        LoginUsuarioActivity.this.startActivity(catalogoActivity);
                    }
                }catch(Exception e){
                    MostraMensagem("Erro : " + e.toString());
                }
            }
        });
    }

    private void MostraMensagem(String str) {
        AlertDialog.Builder dialogo = new AlertDialog.Builder(LoginUsuarioActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("Ok", null);
        dialogo.show();
    }
}