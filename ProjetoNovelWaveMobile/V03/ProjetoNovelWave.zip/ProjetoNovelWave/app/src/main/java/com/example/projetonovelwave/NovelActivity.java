package com.example.projetonovelwave;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.*;
import android.content.Intent;
import android.database.Cursor;

import com.bumptech.glide.Glide;

public class NovelActivity extends Activity {
    TextView txtNomeNovel, txtAutordaNovel, txtQtdCapitulos, txtPostagem, txtStatusdaNovel, txtSinopse;
    ImageView imgCapaNovel;
    Button btFavoritar, btVerCapitulos;
    SQLiteDatabase db;
    int indice;
    Cursor c;
    Intent catalogoActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novel);

        int idNovel = getIntent().getIntExtra("id_novel", -1);

        txtNomeNovel = findViewById(R.id.txtNomeNovel);
        txtAutordaNovel = findViewById(R.id.txtAutordaNovel);
        txtPostagem = findViewById(R.id.txtPostagem);
        txtQtdCapitulos = findViewById(R.id.txtQtdCapitulos);
        txtStatusdaNovel = findViewById(R.id.txtStatusdaNovel);
        txtSinopse = findViewById(R.id.txtSinopse);

        imgCapaNovel = findViewById(R.id.imgCapaNovel);

        btVerCapitulos = findViewById(R.id.btCapitulos);
        btFavoritar = findViewById(R.id.btFavoritar);

        SharedPreferences prefs = getSharedPreferences("NovelWavePrefs", MODE_PRIVATE);
        int usuarioId = prefs.getInt("usuario_id", -1);


        if (usuarioId != -1) {
            try {
                db = openOrCreateDatabase("banconovelwave.db", Context.MODE_PRIVATE, null);
                Cursor c = db.rawQuery(
                        "SELECT * FROM usuarios WHERE id = ?",
                        new String[]{String.valueOf(usuarioId)}
                );

                if (c.getCount() > 0) {
                    c.moveToFirst();
                    indice = 1;
                    atualizarCamposECapa(c);

                }

            }catch(Exception e){
                MostraMensagem("Erro: " + e.toString());
            }

        }else{
            AlertDialog.Builder dialogo = new AlertDialog.Builder(NovelActivity.this);
            dialogo.setTitle("Aviso");
            dialogo.setMessage("Você não está logado!");
            dialogo.setNeutralButton("OK", null);
            dialogo.show();
            catalogoActivity = new Intent(NovelActivity.this, CatalogoActivity.class);
            NovelActivity.this.startActivity(catalogoActivity);

        }

        btFavoritar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    db.execSQL("INSERT INTO novels_fav (idusuario, favnovels) VALUES (?, ?)",
                            new Object[]{usuarioId, idNovel});
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(NovelActivity.this);
                    dialogo.setTitle("Aviso");
                    dialogo.setMessage("Favoritado com sucesso!");
                    dialogo.setNeutralButton("OK", null);
                    dialogo.show();

                }catch(Exception e){
                    MostraMensagem("Erro: " + e.toString());
                }
            }
        });
    }

    private void atualizarCamposECapa(Cursor c) {
        int idNovel = getIntent().getIntExtra("id_novel", -1);

        if (idNovel != -1) {
            Cursor cursor = db.rawQuery(
                    "SELECT * FROM webnovels WHERE id = ?",
                    new String[]{String.valueOf(idNovel)}

            );

            if (cursor != null && cursor.moveToFirst()) {
                txtNomeNovel.setText(cursor.getString(1));
                txtAutordaNovel.setText("Autor:" + cursor.getString(3));
                txtQtdCapitulos.setText("Nª Capítulos: " + cursor.getString(8));
                txtPostagem.setText("Ano:" + cursor.getString(7));
                txtSinopse.setText("Sinopse: \n" + cursor.getString(10));
                txtStatusdaNovel.setText("Status: " + cursor.getString(4));

                String urlImagem = cursor.getString(2);
                Glide.with(imgCapaNovel.getContext())
                        .load(urlImagem)
                        .into(imgCapaNovel);
            } else {
                txtNomeNovel.setText("Nenhuma novel encontrada");
            }

            if (cursor != null) cursor.close();

        } else {
            AlertDialog.Builder dialogo = new AlertDialog.Builder(NovelActivity.this);
            dialogo.setTitle("Aviso");
            dialogo.setMessage("ID de novel não informado!");
            dialogo.setNeutralButton("OK", null);
            dialogo.show();
            catalogoActivity = new Intent(NovelActivity.this, CatalogoActivity.class);
            NovelActivity.this.startActivity(catalogoActivity);
        }

    }

    public void MostraMensagem(String str){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(NovelActivity.this);

        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
}