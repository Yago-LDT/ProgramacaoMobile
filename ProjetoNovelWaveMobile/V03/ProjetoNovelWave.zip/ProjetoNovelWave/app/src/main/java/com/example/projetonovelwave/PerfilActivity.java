package com.example.projetonovelwave;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.AlertDialog;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.*;
import android.content.Intent;
import android.database.Cursor;

import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

public class PerfilActivity extends Activity {
    SQLiteDatabase db;
    int indice;
    Cursor c;
    Intent catalogoActivity, novelActivity;
    TextView txtidfav, txtloginfav, txtemailfav, txtstatusfav, txtnomefav, txtautorfav;
    ImageView imgNovelfav, imganteriorfav, imgproximofav;
    Button btIrNovel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        txtidfav = findViewById(R.id.txtidfav);
        txtloginfav = findViewById(R.id.txtloginfav);
        txtemailfav = findViewById(R.id.txtemailfav);
        txtstatusfav = findViewById(R.id.txtstatusfav);
        txtnomefav = findViewById(R.id.txtnomefav);
        txtautorfav = findViewById(R.id.txtautorfav);

        imgNovelfav = findViewById(R.id.imgNovelfav);
        imganteriorfav = findViewById(R.id.imganteriorfav);
        imgproximofav = findViewById(R.id.imgproximofav);

        btIrNovel = findViewById(R.id.btIrNovel);

        SharedPreferences prefs = getSharedPreferences("NovelWavePrefs", MODE_PRIVATE);
        int usuarioId = prefs.getInt("usuario_id", -1);

        if (usuarioId != -1) {
            try {
                db = openOrCreateDatabase("banconovelwave.db", Context.MODE_PRIVATE, null);
                Cursor c = db.rawQuery(
                        "SELECT * FROM usuarios WHERE id = ?",
                        new String[]{String.valueOf(usuarioId)}
                );

                if (c.getCount() > 0) {
                    c.moveToFirst();
                    indice = 1;
                    atualizarCamposECapa(c);

                    imgproximofav.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (c.getCount() > 0) {
                                if (indice != c.getCount()) {
                                    c.moveToNext();
                                    indice++;
                                    atualizarCamposECapa(c);
                                }
                            }
                        }
                    });

                    imganteriorfav.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (c.getCount() > 0) {
                                if (indice > 1) {
                                    indice--;
                                    c.moveToPrevious();
                                    atualizarCamposECapa(c);
                                }
                            }
                        }
                    });

                    btIrNovel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int idAtual = c.getInt(0); // posição 0 do cursor agora é o ID
                            novelActivity = new Intent(PerfilActivity.this, NovelActivity.class);
                            novelActivity.putExtra("id_novel", idAtual);
                            PerfilActivity.this.startActivity(novelActivity);
                        }
                    });

                } else {
                    txtstatusfav.setText("Nenhum registro");
                }



            }catch(Exception e){
                MostraMensagem("Erro: " + e.toString());
            }

        }else{
            AlertDialog.Builder dialogo = new AlertDialog.Builder(PerfilActivity.this);
            dialogo.setTitle("Aviso");
            dialogo.setMessage("Você não está logado!");
            dialogo.setNeutralButton("OK", null);
            dialogo.show();
            catalogoActivity = new Intent(PerfilActivity.this, CatalogoActivity.class);
            PerfilActivity.this.startActivity(catalogoActivity);

        }



    }


    private void atualizarCamposECapa(Cursor c) {
        SharedPreferences prefs = getSharedPreferences("NovelWavePrefs", MODE_PRIVATE);
        int usuarioId = prefs.getInt("usuario_id", -1);

        Cursor cursor = db.rawQuery(
                "SELECT w.nome, w.caminho_imagem, w.autor FROM novels_fav f " +
                        "JOIN webnovels w ON f.favnovels = w.id " +
                        "WHERE f.idusuario = ?",
                new String[]{String.valueOf(usuarioId)}
        );


        // dados do usuário
        txtemailfav.setText(c.getString(3));
        txtloginfav.setText(c.getString(1));
        txtidfav.setText(c.getString(0));

        // dados da novel favorita
        if (cursor != null && cursor.moveToFirst()) {
            txtnomefav.setText(cursor.getString(0));
            txtautorfav.setText(cursor.getString(2));
            txtstatusfav.setText(indice + " / " + cursor.getCount());

            String urlImagem = cursor.getString(1);
            Glide.with(imgNovelfav.getContext())
                    .load(urlImagem)
                    .into(imgNovelfav);
        } else {
            txtstatusfav.setText("Nenhuma novel favorita");
        }

        if (cursor != null) cursor.close();
    }


    public void MostraMensagem(String str){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(PerfilActivity.this);

        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }

}