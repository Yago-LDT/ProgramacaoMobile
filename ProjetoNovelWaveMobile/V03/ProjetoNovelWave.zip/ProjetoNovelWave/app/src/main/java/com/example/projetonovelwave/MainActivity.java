package com.example.projetonovelwave;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.*;
import android.content.Intent;

public class MainActivity extends Activity {
Button btLogin;
Button btCadastro;
Button btCriarBanco;
Intent cadastrarUsuarioActivity;
Intent loginUsuarioActivity;
SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btCadastro = findViewById(R.id.btCadastro);
        btLogin = findViewById(R.id.btLogin);
        btCriarBanco = findViewById(R.id.btCriarBanco);

        btCriarBanco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
                    db = dbHelper.getWritableDatabase();

                    AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                    dialogo.setTitle("Aviso");
                    dialogo.setMessage("Banco de dados criado com sucesso");
                    dialogo.setNeutralButton("OK", null);
                    dialogo.show();
                }catch(Exception e){
                    MostraMensagem("Erro: " + e.toString());
                }
            }
        });

    btCadastro.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            cadastrarUsuarioActivity = new Intent(MainActivity.this, CadastrarUsuarioActivity.class);
            MainActivity.this.startActivity(cadastrarUsuarioActivity);
        }
    });

    btLogin.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            loginUsuarioActivity = new Intent(MainActivity.this, LoginUsuarioActivity.class);
            MainActivity.this.startActivity(loginUsuarioActivity);
        }
    });
    }

    private void MostraMensagem(String str) {
        AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("Ok", null);
        dialogo.show();
    }
}