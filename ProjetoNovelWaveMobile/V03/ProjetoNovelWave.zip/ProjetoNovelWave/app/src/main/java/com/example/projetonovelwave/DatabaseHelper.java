package com.example.projetonovelwave;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "banconovelwave.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {

        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS usuarios (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "login TEXT NOT NULL, " +
                "senha TEXT NOT NULL, " +
                "email TEXT NOT NULL);");

        db.execSQL("CREATE TABLE IF NOT EXISTS webnovels (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "nome TEXT NOT NULL, " +
                "caminho_imagem TEXT, " +
                "autor TEXT NOT NULL, " +
                "status TEXT, " +
                "genero1 TEXT, " +
                "genero2 TEXT, " +
                "ano_postagem INTEGER, " +
                "num_cap INTEGER, " +
                "ult_at DATETIME, " +
                "sinopse TEXT);");

        db.execSQL("CREATE TABLE IF NOT EXISTS capitulos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "idnovel INTEGER, " +
                "num INTEGER, " +
                "nome TEXT, " +
                "conteudo TEXT, " +
                "data_postagem DATETIME, " +
                "FOREIGN KEY (idnovel) REFERENCES webnovels(id));");

        db.execSQL("CREATE TABLE IF NOT EXISTS novel_cap (" +
                "idnovel INTEGER, " +
                "idcap INTEGER, " +
                "FOREIGN KEY (idnovel) REFERENCES webnovels(id), " +
                "FOREIGN KEY (idcap) REFERENCES capitulos(id));");

        db.execSQL("CREATE TABLE IF NOT EXISTS novels_fav (" +
                "idusuario INTEGER, " +
                "favnovels INTEGER, " +
                "FOREIGN KEY (idusuario) REFERENCES usuarios(id), " +
                "FOREIGN KEY (favnovels) REFERENCES webnovels(id));");

        db.execSQL("CREATE TRIGGER novo_novel_cap AFTER INSERT ON capitulos " +
                "FOR EACH ROW BEGIN " +
                "INSERT INTO novel_cap (idnovel, idcap) VALUES (NEW.idnovel, NEW.id); " +
                "END;");

        db.execSQL("CREATE TRIGGER novo_update_webnovels AFTER INSERT ON capitulos " +
                "FOR EACH ROW BEGIN " +
                "UPDATE webnovels SET num_cap = num_cap + 1, ult_at = NEW.data_postagem WHERE id = NEW.idnovel; " +
                "END;");

        db.execSQL("CREATE TRIGGER tirar_update_webnovels BEFORE DELETE ON capitulos " +
                "FOR EACH ROW BEGIN " +
                "UPDATE webnovels SET num_cap = num_cap - 1 WHERE id = OLD.idnovel; " +
                "END;");

        db.execSQL("CREATE TRIGGER tirar_usuario_favs BEFORE DELETE ON usuarios " +
                "FOR EACH ROW BEGIN " +
                "DELETE FROM novels_fav WHERE idusuario = OLD.id; " +
                "END;");

        db.execSQL("CREATE TRIGGER tirar_novel_favs BEFORE DELETE ON webnovels " +
                "FOR EACH ROW BEGIN " +
                "DELETE FROM novels_fav WHERE idnovel = OLD.id; " +
                "END;");

        db.execSQL("INSERT INTO webnovels (nome, caminho_imagem, autor, status, genero1, genero2, ano_postagem, num_cap, ult_at, sinopse) VALUES (" +
                "'Shadow Slave', " +
                "'https://i.pinimg.com/736x/2f/ce/d0/2fced04904a0776716e9860450ecf467.jpg', " +
                "'Guiltythree', " +
                "'Em andamento', " +
                "'Ação', " +
                "'Fantasia', " +
                "2022, " +
                "2370, " +
                "'2025-05-27 10:00:00', " +
                "'Growing up in poverty, Sunny never expected anything good from life. However, even he did not anticipate being chosen by the Nightmare Spell and becoming one of the Awakened - an elite group of people gifted with supernatural powers. Transported into a ruined magical world, he found himself facing against terrible monsters - and other Awakened - in a deadly battle of survival.\n" +
                "Whats worse, the divine power he received happened to possess a small, but potentially fatal side effect...\n')"
        );

        db.execSQL("INSERT INTO webnovels (nome, caminho_imagem, autor, status, genero1, genero2, ano_postagem, num_cap, ult_at, sinopse) VALUES (" +
                "'Pale Lights', " +
                "'https://i.pinimg.com/736x/4b/3f/10/4b3f104a64552bace05ba1b4c60ade16.jpg', " +
                "'ErraticErrata', " +
                "'Em andamento', " +
                "'Aventura', " +
                "'Ação', " +
                "2022, " +
                "132, " +
                "'2025-05-27 10:00:00', " +
                "'\"Pale Lights,\" a fantasy adventure story by ErraticErrata, " +
                "follows conman Tristan Abrascal and minor noblewoman Angharad Tredegar as they flee into the Watch, " +
                "a military order that hunts devils. The world of Vesper, a colossal cavern beneath the earth," +
                " is built on the ruins of older civilizations, with humanity living in the shadow of the Glare, light spilling from above." +
                " The story explores the dangers of the Gloam, the vast darkness where old gods and devils dwell, and the fragile peace thats " +
                "falling apart amidst political intrigue and the rise of dark powers.')"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
