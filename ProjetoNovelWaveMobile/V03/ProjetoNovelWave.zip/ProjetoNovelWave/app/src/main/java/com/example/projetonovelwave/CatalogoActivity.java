package com.example.projetonovelwave;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.app.AlertDialog;
import android.database.Cursor;
import com.bumptech.glide.Glide;
import android.util.Log;


public class CatalogoActivity extends Activity {
    Button btIrPerfil;
    Button btIrNovel;
    TextView txtstatus_registro, txtnome, txtautor, txtgenero, txtgenero2, txtano;
    ImageView imganterior, imgproximo, imgNovel;
    int indice;
    Cursor c;
    SQLiteDatabase db;
    Intent perfilActivity, novelActivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogo);

        txtstatus_registro = findViewById(R.id.txtstatus_registro);
        txtnome = findViewById(R.id.txtnome);
        txtautor = findViewById(R.id.txtautor);
        txtgenero = findViewById(R.id.txtgenero);
        txtgenero2 = findViewById(R.id.txtgenero2);
        txtano = findViewById(R.id.txtano);

        imganterior = findViewById(R.id.imganterior);
        imgproximo = findViewById(R.id.imgproximo);
        imgNovel = findViewById(R.id.imgNovel);

        btIrPerfil = findViewById(R.id.btIrperfil);
        btIrNovel = findViewById(R.id.btIrNovel);
        try {
            db = openOrCreateDatabase("banconovelwave.db", Context.MODE_PRIVATE, null);
            c = db.query("webnovels", new String[]{"id", "nome", "autor", "ano_postagem", "genero1", "genero2", "caminho_imagem"},
                    null, null, null, null, null, null);

            if (c.getCount() > 0) {
                c.moveToFirst();
                indice = 1;
                atualizarCamposECapa();

            } else {
                txtstatus_registro.setText("Nenhum registro");
            }

            imgproximo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (c.getCount() > 0) {
                        if (indice != c.getCount()) {
                            c.moveToNext();
                            indice++;
                            atualizarCamposECapa();
                        }
                    }
                }
            });

            imganterior.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (c.getCount() > 0) {
                        if (indice > 1) {
                            indice--;
                            c.moveToPrevious();
                            atualizarCamposECapa();
                        }
                    }
                }
            });

            btIrPerfil.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    perfilActivity = new Intent(CatalogoActivity.this, PerfilActivity.class);
                    CatalogoActivity.this.startActivity(perfilActivity);
                }
            });

            btIrNovel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int idAtual = c.getInt(0); // posição 0 do cursor agora é o ID
                    novelActivity = new Intent(CatalogoActivity.this, NovelActivity.class);
                    novelActivity.putExtra("id_novel", idAtual);
                    CatalogoActivity.this.startActivity(novelActivity);
                }
            });
        } catch (Exception e) {
            MostraMensagem("Erro: " + e.toString());
        }
    }

    private void atualizarCamposECapa() {
        txtnome.setText(c.getString(1));       // nome
        txtautor.setText(c.getString(2));      // autor
        txtano.setText(c.getString(3));        // ano_postagem
        txtgenero.setText(c.getString(4));     // genero1
        txtgenero2.setText(c.getString(5));    // genero2
        txtstatus_registro.setText(indice + " / " + c.getCount());

        String urlImagem = c.getString(6);     // caminho_imagem
        Glide.with(imgNovel.getContext())
                .load(urlImagem)
                .into(imgNovel);
    }

    public void MostraMensagem(String str){
        AlertDialog.Builder dialogo = new AlertDialog.Builder(CatalogoActivity.this);

        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
}
