package com.example.visualizadorimagens2;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import android.view.*;

public class VisualizandoImagensActivity extends Activity {

    ImageSwitcher imgFoto, imgSobre;

    Button btanterior, btproximo;

    int indice = 1;

    public void mostrarInfoPersonagem()
    {
        switch (indice) {
            case 1: {
                imgFoto.setImageResource(R.drawable.foto_deadpool);
                imgSobre.setImageResource(R.drawable.frase_sobre_deadpool);
            }
            break;
            case 2: {
                imgSobre.setImageResource(R.drawable.frase_sobre_colossus);
                imgFoto.setImageResource(R.drawable.foto_colossus);
            }
            break;
            case 3: {
                imgFoto.setImageResource(R.drawable.foto_megasonico);
                imgSobre.setImageResource(R.drawable.frase_sobre_megasonico);
            }
            break;
            case 4:
            {
                imgFoto.setImageResource(R.drawable.aot);
                imgSobre.setImageResource(R.drawable.sobreaot);
            }

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizando_imagens);

        Animation in = AnimationUtils.loadAnimation(this,android.R.anim.slide_in_left);
        Animation out = AnimationUtils.loadAnimation(this,android.R.anim.slide_out_right);

        imgFoto = findViewById(R.id.imgFoto);
        btanterior = findViewById(R.id.btanterior);
        btproximo = findViewById(R.id.btproximo);

        imgFoto.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView myView = new ImageView(getApplicationContext());
                myView.setScaleType(ImageView.ScaleType.FIT_XY);
                myView.setLayoutParams(new ImageSwitcher.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT));
                return myView;
            }
        });

        imgSobre = findViewById(R.id.imgSobre);

        imgSobre.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView myView = new ImageView(getApplicationContext());
                myView.setScaleType(ImageView.ScaleType.FIT_XY);
                myView.setLayoutParams(new ImageSwitcher.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT));

                return myView;
            }
        });

        imgFoto.setImageResource(R.drawable.foto_deadpool);
        imgFoto.setInAnimation(in);
        imgFoto.setOutAnimation(out);

        imgSobre.setImageResource(R.drawable.frase_sobre_deadpool);
        imgSobre.setInAnimation(in);
        imgSobre.setOutAnimation(out);


        btanterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(indice > 1){
                    indice--;
                    mostrarInfoPersonagem();
                }
            }
        });

        btproximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(indice < 4){
                    indice++;
                    mostrarInfoPersonagem();
                }
            }
        });

    }
}